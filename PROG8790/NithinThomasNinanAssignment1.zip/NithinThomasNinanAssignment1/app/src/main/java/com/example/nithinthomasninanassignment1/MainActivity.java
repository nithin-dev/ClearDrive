package com.example.nithinthomasninanassignment1;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.nithinthomasninanassignment1.databinding.ActivityMainBinding;

//the main activity class
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ActivityMainBinding activityMainBinding;

    //setting default value to stopwatch
    private int timer = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = activityMainBinding.getRoot();
        setContentView(view);
        initializeChronometer();
        setListeners();
    }

    //initializing the stopwatch
    private void initializeChronometer() {

        //setting the format of stopwatch to 00:00:00
        activityMainBinding.chronometer.setFormat("00:%s");
        activityMainBinding.chronometer.setBase(SystemClock.elapsedRealtime());

    }

    //setting the listeners
    private void setListeners() {
        activityMainBinding.btnStart.setOnClickListener(this);
        activityMainBinding.btnStop.setOnClickListener(this);
        activityMainBinding.btnReset.setOnClickListener(this);
    }


    //button click functionalities
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnStart) {
            //start the timer
            startTimer();
        } else if (v.getId() == R.id.btnStop) {
            //stop the timer
            stopTimer();
        } else if (v.getId() == R.id.btnReset) {
            //reset the timer
            resetTimer();
        }
    }

    private void startTimer() {
        //disabling start button
        activityMainBinding.btnStart.setEnabled(false);
        activityMainBinding.btnStop.setEnabled(true);
        activityMainBinding.btnReset.setEnabled(true);

        //setting background to buttons
        activityMainBinding.btnStart.setBackground(ContextCompat.getDrawable(this, R.drawable.curved_bg_grey));
        activityMainBinding.btnStop.setBackground(ContextCompat.getDrawable(this, R.drawable.curved_bg_blue));
        activityMainBinding.btnReset.setBackground(ContextCompat.getDrawable(this, R.drawable.curved_bg_blue));
        activityMainBinding.btnStart.setTextColor(ContextCompat.getColor(this, R.color.dark_grey));

        //changing button text when clicked
        activityMainBinding.btnStop.setTextColor(ContextCompat.getColor(this, R.color.white));
        activityMainBinding.btnReset.setTextColor(ContextCompat.getColor(this, R.color.white));
        if (timer == 0) {
            //starting the stopwatch
            activityMainBinding.chronometer.start();
            timer = 1;
        }
    }

    private void stopTimer() {
        //disabling stop button
        activityMainBinding.btnStart.setEnabled(true);
        activityMainBinding.btnStop.setEnabled(false);
        activityMainBinding.btnReset.setEnabled(true);
        activityMainBinding.btnStart.setBackground(ContextCompat.getDrawable(this, R.drawable.curved_bg_blue));
        activityMainBinding.btnStop.setBackground(ContextCompat.getDrawable(this, R.drawable.curved_bg_grey));
        activityMainBinding.btnReset.setBackground(ContextCompat.getDrawable(this, R.drawable.curved_bg_blue));
        activityMainBinding.btnStart.setTextColor(ContextCompat.getColor(this, R.color.white));
        activityMainBinding.btnStop.setTextColor(ContextCompat.getColor(this, R.color.dark_grey));
        activityMainBinding.btnReset.setTextColor(ContextCompat.getColor(this, R.color.white));
        if (timer == 1) {
            //stopping the stopwatch
            activityMainBinding.chronometer.stop();
            timer = 0;
        }
    }

    private void resetTimer() {

        //disabling reset button
        activityMainBinding.btnStart.setEnabled(true);
        activityMainBinding.btnStop.setEnabled(true);
        activityMainBinding.btnReset.setEnabled(false);
        activityMainBinding.btnStart.setBackground(ContextCompat.getDrawable(this, R.drawable.curved_bg_blue));
        activityMainBinding.btnReset.setBackground(ContextCompat.getDrawable(this, R.drawable.curved_bg_blue));
        activityMainBinding.btnStop.setBackground(ContextCompat.getDrawable(this, R.drawable.curved_bg_blue));
        activityMainBinding.btnStart.setTextColor(ContextCompat.getColor(this, R.color.white));
        activityMainBinding.btnStop.setTextColor(ContextCompat.getColor(this, R.color.white));
        activityMainBinding.btnReset.setTextColor(ContextCompat.getColor(this, R.color.white));

        //resetting the stopwatch
        activityMainBinding.chronometer.setBase(SystemClock.elapsedRealtime());
    }
}
