<?php
    $lLabNumber = 28;
    $lTitle = "Lab 28: Cross-Site Scripting - Defending Against Cross-site Scripting";
    $lQuestion = "What is the HTML-encoded version of the ampersand character?";
    $lChoice_1 = "&amp;#x41;";
    $lChoice_2 = "&amp;#x50;";
    $lChoice_3 = "&amp;#x92;";
    $lChoice_4 = "&amp;#x20;";
    $lChoice_5 = "&amp;amp;";
    $lCorrectAnswer = 5;

    require_once("labs/lab-template.inc");
?>