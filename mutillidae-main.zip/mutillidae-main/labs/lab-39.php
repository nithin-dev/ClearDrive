<?php
$lLabNumber = 39;
$lTitle = "Lab 39: Password Management - Password cracking";
$lQuestion = "Crack the password in the level-1-no-salt-sha1.txt file. The format is Raw-SHA1. What is the password for user11?";
$lChoice_1 = "twitter";
$lChoice_2 = "password";
$lChoice_3 = "Password1";
$lChoice_4 = "tiefighter";
$lChoice_5 = "wordpass";
$lCorrectAnswer = 1;

require_once("labs/lab-template.inc");
?>