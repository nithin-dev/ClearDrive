<?php
    $lLabNumber = 20;
    $lTitle = "Lab 20: Insecure Direct Object References - Extracting User Accounts with Local File Inclusion";
    $lQuestion = "The local file inclusion allows /etc/passwd to be extracted. Which of these accounts exists on the Mutillidae Linux server?";
    $lChoice_1 = "slack";
    $lChoice_2 = "ntp";
    $lChoice_3 = "george";
    $lChoice_4 = "fred";
    $lChoice_5 = "cmdline";
    $lCorrectAnswer = 2;

    require_once("labs/lab-template.inc");
?>