<?php
$lLabNumber = 50;
$lTitle = "Lab 50: Server Configuration - Testing HTTP Response Headers";
$lQuestion = "The value of the of the X-XSS-Protection header is incorrect. What should the value be?";
$lChoice_1 = "deny";
$lChoice_2 = "1; mode=block";
$lChoice_3 = "31546000; includeSubdomains";
$lChoice_4 = "42";
$lChoice_5 = "no-store, no-cache";
$lCorrectAnswer = 2;

require_once("labs/lab-template.inc");
?>
