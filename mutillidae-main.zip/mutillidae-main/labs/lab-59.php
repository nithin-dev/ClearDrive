<?php
$lLabNumber = 59;
$lTitle = "Lab 59: JSON Web Token (JWT) Security - SQL Injection via JWT";
$lQuestion = "Using SQL injection on the Current User Information page, what is the password for the Admin user?";
$lChoice_1 = "adminpass";
$lChoice_2 = "password";
$lChoice_3 = "mutillidae";
$lChoice_4 = "webtoken";
$lChoice_5 = "trident";
$lCorrectAnswer = 1;

require_once("labs/lab-template.inc");
?>
