<?php
    $lLabNumber = 19;
    $lTitle = "Lab 19: Insecure Direct Object References - Extracting User Accounts";
    $lQuestion = "The local file inclusion allows /etc/passwd to be extracted. Which of these accounts exists on the Mutillidae Linux server?";
    $lChoice_1 = "sally";
    $lChoice_2 = "root";
    $lChoice_3 = "george";
    $lChoice_4 = "kelli";
    $lChoice_5 = "bob";
    $lCorrectAnswer = 2;

    require_once("labs/lab-template.inc");
?>