    <?php
    $lLabNumber = 5;
    $lTitle = "Lab 5: How the Web Really Works - Bypassing Client-side Security";
    $lQuestion = "In the Client-site Security Control Challenge, what attribute code causes the Vanishing Text Box input element to vanish?";
    $lChoice_1 = 'type="hidden"';
    $lChoice_2 = 'input.hidden="true"';
    $lChoice_3 = 'readonly="readonly"';
    $lChoice_4 = 'vanish="true"';
    $lChoice_5 = 'onmouseover="javascript:this.type=\'hidden\';"';
    $lCorrectAnswer = 5;

    require_once("labs/lab-template.inc");
?>